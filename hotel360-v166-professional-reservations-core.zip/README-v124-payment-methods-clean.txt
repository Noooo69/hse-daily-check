Hotel360 v124 — Payment Methods Clean

Generated: 2026-06-12T02:33:31

Change:
- Removed the following payment method options:
  إيداع بنكي، رابط دفع، تابي، تمارا، شركة / آجل، قسيمة / كوبون
- Kept payment methods:
  مدى، فيزا، ماستر كارد، أبل باي، STC Pay، نقد، تحويل بنكي، أخرى
- Payment status remains separate:
  مدفوع، جزئي، غير مدفوع

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- paymentMethod select was inspected after edit.
- Removed options are not present inside paymentMethod.
- "غير مدفوع" is not present inside paymentMethod.
- v122 government workflow retained.
- v123 ID type fix retained.
- Country list verified clean.