Hotel360 v127 — Minimal One Page Invoice

Generated: 2026-06-12T13:42:57

User issue:
- Invoice screen and print were too large.
- Big green area and the lower barcode wasted space.
- Need one page, or two at most.

Fix:
- Replaced invoice preview and invoice print window with a minimal A4 invoice.
- Removed the lower barcode entirely.
- Removed repeated QR notes and the large empty green area.
- Kept only one compact QR for the digital invoice.
- Designed for one A4 page in normal cases, two only if notes/data are unusually long.

Retained:
- Digital invoice QR.
- v126 print override.
- v124 payment method cleanup.
- v122 Tourism/Shomoos workflow.
- Country list verified clean.

QA:
- JavaScript checked with node --check for all inline scripts.
- invoicePreview and showInvoice are overridden in the final v127 script.
- v127 script does not call the old barcode renderer.