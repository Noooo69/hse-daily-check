Hotel360 v158 — Signup Name Binding Fix

BASE
- Built directly on v157 — Local Signup Queue Fix.
- No older project version was used.

FIX
- Corrected the signup name input binding.
- The signup form now uses id="signupName", matching signup().
- This fixes the false "enter name first" validation when the name field is filled.

UNCHANGED
- Housing assignment logic.
- Incident/report logic.
- Permission rules.
- Admin approval routing.
- Local pending signup queue behavior from v157.

QA
- JavaScript syntax checked with Node.js.
- Signup input/function ID consistency checked.
- Restricted-name scan checked.
- Screen/self capture API scan checked.
