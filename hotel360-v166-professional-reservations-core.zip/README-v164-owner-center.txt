Hotel360 v164 — Owner Center

Baseline:
- Built directly on Hotel360 v163 — Mobile LAN Launcher.
- Existing check-in, issue, purchasing, permissions, Supabase, role-home and LAN launcher behavior retained.

New section:
- مركز المالك — Owner Center.
- New role: مالك المجموعة (group_owner).
- Owner role is executive/read-only and does not gain operational hotel pages.
- Main admin can open Owner Center for testing and can enter supplementary monthly finance figures.

Owner Center views:
- Group summary.
- Hotels overview.
- Revenue and collections.
- Purchases across hotels.
- Maintenance status and manually recorded maintenance cost.
- Expenses and supplementary finance ledger.
- Pending purchase approvals.
- Executive alerts.

Group metrics:
- Total revenue.
- Collected revenue.
- Total recorded cost.
- Approximate net.
- Active hotels.
- Rooms and occupancy.
- Open/high-risk issues.
- Pending approvals and unpriced purchase requests.

Data notes:
- Live revenue uses Hotel360 check-in/campaign totals.
- Purchase cost uses recorded purchase price/cost fields when present.
- Maintenance and other external costs can be entered monthly by the main admin.
- v164 stamps check-ins, purchases and campaigns with the current hotel when hotel metadata is missing so future group aggregation can separate hotels.

Security / permissions:
- group_owner can access Owner Center only.
- group_owner cannot open hotel operations, admin, reception, rooms, issues, purchases, parts or smart operations pages directly.
- Main admin retains existing permissions plus Owner Center.
