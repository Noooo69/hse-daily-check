Hotel360 v160 — Role Home Engine

Base: v159 only.

Added:
- Central H360_ROLE_UI registry for role-specific home experiences.
- New "واجهتي" role-home entry for supported roles.
- Reception role home with today arrival/departure, occupied/available rooms, active guests, and allowed quick actions.
- Maintenance manager role home with open/critical issues, stopped rooms, active purchase requests, and allowed quick actions.
- Electrician role home with role-filtered electrical issues, priority indicators, and parts access.
- Supported local approved accounts land on roleHome after login.

Unchanged:
- Existing housing/check-in business flow.
- Issue routing/closure business rules.
- Purchase workflow.
- Existing v159 page permissions; roleHome only links to pages already allowed for the current role.
- Admin remains full-control; no admin capability is granted to the three role homes.

Implementation safety:
- No render wrapper.
- No appView wrapper chain; appView/page/title are direct end-of-file replacements.
- No MutationObserver, interval, or repeating timer added.
