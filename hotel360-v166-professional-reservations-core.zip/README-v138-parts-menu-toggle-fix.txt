Hotel360 v138 — Parts Menu Toggle Fix

Generated: 2026-06-19T05:54:51

User issue:
- In the right sidebar, the Parts Catalog arrow opens the submenu but cannot close it by clicking the same arrow again.

Root cause:
- The parent button called setPartsFilter(...).
- setPartsFilter always sets state.page='parts'.
- The menu open state was tied to state.page==='parts'.
- Therefore once you are on Parts, the menu remains open forever.

Fix:
1) Added togglePartsMenu().
2) Parent Parts Catalog button now calls togglePartsMenu(), not setPartsFilter().
3) Added state.v138PartsMenuOpen.
4) When on Parts page:
   - clicking parent toggles submenu open/closed.
5) When not on Parts page:
   - clicking parent opens Parts page and expands submenu.
6) Choosing a submenu shortcut still uses setPartsFilter and keeps the menu open.
7) Arrow changes between ▾ and ▴.

Retained:
- v137 stable permissions without recursion.
- v130 parts image storage.
- v129 one-page landscape invoice.
- Country list verified clean.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard/hoisting hazard scan: 0 hazards.