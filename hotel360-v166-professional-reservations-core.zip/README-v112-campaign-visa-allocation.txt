Hotel360 v112 — Campaign Visa Allocation

Built above v111 / v107 / v104.

New feature:
- Import campaign visa/passenger list from TXT/CSV or pasted text.
- PDF upload is accepted for reference and first-pass extraction when the PDF contains selectable text.
- Scanned/image PDFs need OCR; the system will not reliably extract names from image-only PDFs in static mode.
- Distributes imported people across the rooms already reserved by the campaign according to each room capacity.
- Stores distribution per campaign and shows visa count in campaign table and room cards.
- Campaign check-in uses the distributed room guest count and keeps guest names in notes/history.

Important:
- Rooms remain booked as whole rooms. Bed count is only operational capacity for distribution.
- v104 digital invoice QR and mobile print fixes are retained.
- v107 reception layout repair is retained.
- v111 Cloudflare direct local login is retained.