Hotel360 v120 — Tourism/Shomoos + Tax Ledger

Upload this ZIP to Cloudflare using New deployment / Direct Upload.
Use the existing project, not a new project, if you want to keep the same URL.

New features:
1) Reception now has two buttons: سياحة and شموس.
2) These screens prepare and export guest data for future official integration.
3) Check-in now includes Municipality/Tourism fee default 2.5%.
4) Invoice now shows VAT and municipality fee like the supplied sample.
5) Invoice includes an Informational Invoice ledger with Debit/Credit and Open Balance.

Important:
- This is not an official Shomoos/Tourism API connection yet.
- This version preserves v104 QR/digital invoice/mobile print fixes.