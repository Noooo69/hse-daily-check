Hotel360 v125 — Compact Invoice Print

Generated: 2026-06-12T13:20:13

Purpose:
- Fix checkout invoice printing that was producing 4 pages.
- Default invoice window now uses compact A4 print mode.
- Added two print buttons:
  1) طباعة مختصرة A4 — designed to print on 1 or 2 pages.
  2) طباعة كاملة — keeps the full large invoice design.

Print changes:
- A4 portrait page size with 7mm margins.
- QR reduced from a very large block to a compact scannable block.
- Hero/header tightened.
- Amount, guest, stay, payment tables compacted.
- Barcode note/signatures hidden in compact print to avoid extra pages.
- Page-break rules added to avoid awkward blank pages.

Retained:
- v124 clean payment methods.
- v123 ID type fix.
- v122 Tourism/Shomoos workflow.
- v104 digital QR invoice behavior.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Compact print CSS present.
- showInvoice opens with v125 compact print mode by default.
- Removed payment methods still absent.
- Country list verified clean.