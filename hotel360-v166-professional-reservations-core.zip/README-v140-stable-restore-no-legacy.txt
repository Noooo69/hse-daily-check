Hotel360 v140 — Stable Restore No legacy unstable build

Generated: 2026-06-19T06:17:33

Reason:
- User reported legacy unstable build caused the old freeze problem again: menus/buttons stopped responding.
- Emergency restore built from v138 stable.

What is included:
- v138 parts menu toggle fix.
- v137 stable permissions with no recursion.
- v130 parts image storage.
- v129 one-page landscape invoice.

What is removed:
- legacy unstable build operational intelligence script.
- legacy unstable build temporary state keys are deleted on load: roomLocks, issuePhotos, shiftHandovers, techCustody, vipSensitive, govChecklist, legacy unstable buildPartLinkedRoom.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard hazard scan: 0 hazards.
- legacy unstable build script absent.
- Country list verified clean.