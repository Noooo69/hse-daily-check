Hotel360 v151 — Dashboard Cleanup

Generated: 2026-06-19T22:08:00

Built on:
- v150 VIP Sensitive Center
- v149 Room Loss Indicator
- v148 Department Performance
- v147 Government Visit Readiness
- v146 Technician Custody
- v145 Parts Room Link
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented:
- UI cleanup only.
- Reorganized manager dashboard into clear collapsible sections:
  * Operations / rooms / losses
  * Issues / department performance
  * Government visit readiness
  * VIP and sensitive notes
- Added top summary cards:
  * open issues
  * affected rooms
  * estimated room loss
  * government readiness
  * open VIP notes
- Added quick navigation buttons:
  * Reception
  * Rooms
  * Issues
  * Parts
  * Purchases
- Removes duplicate stacked v143-v150 panels from the legacy dashboard output and shows them in organized sections.

No feature logic changes:
- Does not modify Reception, Issues, Parts, Purchases, Rooms behavior.
- No change to permissions, photos, room blocking, handover, custody, or calculations.

Safety:
- No legacy unstable build script.
- No preview mode.
- No appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.