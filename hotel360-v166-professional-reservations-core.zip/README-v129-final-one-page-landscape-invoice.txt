Hotel360 v129 — Final One Page Landscape Invoice

Generated: 2026-06-12T13:59:13

Issue:
- v128 still printed 3 pages on Edge.
- The summary line was duplicated and still taking vertical height.

Fix:
- New invoice print mode uses A4 Landscape, not portrait.
- Single dashboard-style page.
- No duplicated summary row.
- One QR only.
- No lower barcode.
- Header + charges + guest/stay/payment + signatures all fit into one A4 landscape page.
- Print CSS sets A4 landscape and fixed 285mm x 198mm page content.

Retained:
- Digital invoice QR.
- v124 payment methods.
- v122 Tourism/Shomoos workflow.
- Country list verified clean.

QA:
- JavaScript syntax checked with node --check.
- Final v129 script overrides invoicePreview and showInvoice.
- A4 landscape CSS present.