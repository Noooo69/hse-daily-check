Hotel360 v148 — Department Performance

Generated: 2026-06-19T21:51:48

Built on:
- v147 Government Visit Readiness
- v146 Technician Custody
- v145 Parts Room Link
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented stage 8:
- Department performance panel on manager dashboard.
- Tracks:
  * total issues
  * open issues
  * closed issues
  * waiting approval
  * delayed/high-impact issues
  * close rate
- Groups issues by current owner/department.
- Ranks departments needing follow-up based on open/risky/delayed/approval load.
- Shows critical/high-impact open issue table.
- Adds quick button to open Issues page.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render/appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.