Hotel360 v154 — Dashboard Sections Bottom

Generated: 2026-06-20T00:42:41

Built on:
- v153 Sidebar Professional Cleanup
- v152 All Interfaces Cleanup
- v151 Dashboard Cleanup
- v150 VIP Sensitive Center
- v149 Room Loss Indicator
- v148 Department Performance
- v147 Government Visit Readiness
- v146 Technician Custody
- v145 Parts Room Link
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented:
- Dashboard visual order fix only.
- Moves the accordion/detail sections to the bottom of manager dashboard.
- The original manager dashboard content, including active purchase requests, appears before the detailed accordion sections.
- Adds a small note and title before the moved sections:
  * أقسام المتابعة التفصيلية
- Keeps the v153 sidebar styling.

No business logic changes:
- Does not modify Reception, Issues, Parts, Purchases, Rooms behavior.
- Does not modify permissions, data, calculations, blocking, photos, custody, or handover.
- Does not override render or appView.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render wrapper.
- No appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.