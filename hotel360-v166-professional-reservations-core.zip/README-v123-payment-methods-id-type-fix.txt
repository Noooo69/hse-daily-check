Hotel360 v123 — Payment Methods + ID Type Cleanup
Generated: 2026-06-12T02:30:13

Base:
- Built over v122 Government Real Workflow.

Changes:
- Expanded check-in payment method list.
- Removed "غير مدفوع" from payment method because it belongs to payment status, not payment method.
- Kept payment status as: مدفوع / جزئي / غير مدفوع.
- Removed "بطاقة أحوال" from ID type dropdown; kept: هوية وطنية / إقامة / جواز سفر.
- Updated edit prompt payment examples.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- index.html exists in root.
- images/tourism-logo.webp exists.
- images/shomoos-logo.jpg exists.
- Country list verified clean.
- Payment select no longer contains "غير مدفوع" as a payment method.
- ID type select no longer contains "بطاقة أحوال".