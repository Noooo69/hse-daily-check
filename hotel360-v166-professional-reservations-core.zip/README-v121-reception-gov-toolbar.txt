Hotel360 v121
- Added fixed government toolbar inside Reception section only.
- Moved Tourism and Shomoos actions to upper white area above reception tabs.
- Added responsive logos, status badges, and demo integration panel.