Hotel360 v137 — Stable Permissions No Recursion

Generated: 2026-06-19T05:44:19

Built from:
- User-uploaded stable file: hotel360-v130-parts-image-storage(1).zip

Root cause found in previous broken versions:
- v131/v132/v133/v134/v135/v136 introduced patterns like:
  const oldAdmin = typeof admin === 'function' ? admin : null;
  function admin() { return oldAdmin(); }
- Because JavaScript function declarations are hoisted, the "old" variable captures the new function itself, not the old one.
- This creates infinite recursion at runtime. node --check cannot catch it because the syntax is valid.
- v133 was the worst: currentRoleKey/appView/accountPill/admin/logout recursive wrapper hazardd, which can freeze almost all clicks.
- v135/v136 still had admin recursive wrapper hazard, so if the browser stored state.page='admin', the app freezes immediately.

v137 fix:
- Built again from v130 stable.
- Did NOT include v131/v132/v133/v134/v135/v136 scripts.
- Added permissions using window assignment inside an IIFE.
- Captures old admin safely as window.admin before assigning window.admin.
- No render wrapper.
- No preview mode.
- No function recursive wrapper hazard patterns.

Retained:
- v130 parts image storage.
- v129 one-page landscape invoice.
- v124 payment method cleanup.
- v122 Tourism/Shomoos workflow.
- Country list verified clean.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard/hoisting hazard scan: 0 hazards.
- No v131-v136 scripts remain.