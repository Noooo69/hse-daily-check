Hotel360 v130 — Parts Catalog Image Storage

Generated: 2026-06-15T22:51:44

Goal:
- Prepare Parts Catalog image saving before adding real images.
- Avoid losing images during normal site updates.
- Avoid storing large base64 images inside localStorage.

Implemented:
1) Images are saved in IndexedDB database: hotel360_parts_images_v130
2) Custom part image is stored as a stable reference, not raw image text in localStorage.
3) Existing/base parts can have their image replaced from the card using "تغيير الصورة".
4) Stored images load automatically after render.
5) Legacy custom images stored as data:image are migrated to IndexedDB once.
6) Export backup JSON for images/custom parts.
7) Import backup JSON for images/custom parts.
8) Cart thumbnails support stored image references.
9) Admin-only image add/change/remove.

Persistence:
- Images survive normal Cloudflare/Netlify update when deployed to the same domain/origin.
- If domain changes, browser/device changes, or browser data is cleared, use Export/Import backup.

Retained:
- v129 one-page landscape invoice.
- v124 payment method cleanup.
- v122 Tourism/Shomoos workflow.
- Country list verified clean.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Final v130 script overrides partsView/manual image save/cart image rendering.
- IndexedDB functions present.
- Export/import functions present.