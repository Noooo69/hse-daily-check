Hotel360 v149 — Room Loss Indicator

Generated: 2026-06-19T21:55:07

Built on:
- v148 Department Performance
- v147 Government Visit Readiness
- v146 Technician Custody
- v145 Parts Room Link
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented stage 9:
- Real room loss indicator on manager dashboard.
- Calculates stopped/blocked/maintenance/clean/purchase rooms.
- Formula:
  stopped days × nightly rate = estimated room loss.
- Shows:
  * affected rooms count
  * total stopped days
  * nightly rate used
  * estimated loss
- Shows top affected rooms with reason and quick action.
- Quick actions:
  * open rooms page
  * open issues page

Safety:
- No legacy unstable build script.
- No preview mode.
- No render/appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.