@echo off
setlocal
cd /d "%~dp0"
title Hotel360 v164 - Owner Center

for /f "usebackq delims=" %%I in (`powershell -NoProfile -Command "$r=Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue ^| Sort-Object RouteMetric,InterfaceMetric ^| Select-Object -First 1; if($r){Get-NetIPAddress -InterfaceIndex $r.InterfaceIndex -AddressFamily IPv4 -ErrorAction SilentlyContinue ^| Where-Object {$_.IPAddress -notlike '169.254*'} ^| Select-Object -First 1 -ExpandProperty IPAddress}"`) do set "LANIP=%%I"

if not defined LANIP set "LANIP=YOUR-PC-IP"

echo =====================================================
echo Hotel360 v164
 echo PC link   : http://localhost:8080
 echo Phone link: http://%LANIP%:8080
 echo =====================================================
echo.
echo Keep this window open while using Hotel360.
echo For phone access, connect the phone and PC to the SAME Wi-Fi.
echo 5G/mobile-data access requires publishing Hotel360 to a public host.
echo.
start "" "http://localhost:8080"

where python >nul 2>nul
if %errorlevel%==0 (
  python -m http.server 8080 --bind 0.0.0.0
) else (
  where py >nul 2>nul
  if %errorlevel%==0 (
    py -m http.server 8080 --bind 0.0.0.0
  ) else (
    echo Python was not found. Install Python and enable Add Python to PATH.
    pause
  )
)
