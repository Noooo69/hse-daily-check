Hotel360 v142 — Issue Before/After Photos

Generated: 2026-06-19T19:10:17

Built on:
- v141 Smart Room Blocking
- v140 Stable Restore
- v138 Parts menu toggle
- v137 Stable permissions
- v130 Parts image storage

Implemented stage 2:
- Before/after photo proof on issue rows.
- Buttons: قبل / بعد for each issue where the role can act.
- Photos are compressed before saving.
- Photos are stored in IndexedDB using the existing v130 image storage, not heavy localStorage.
- Blocking/high/risky issues cannot close until an after-repair photo is uploaded.
- Close button routes through v142CloseIssueWithPhotoCheck, then v141 safe close.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render/appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.