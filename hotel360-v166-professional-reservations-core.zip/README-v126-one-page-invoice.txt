Hotel360 v126 — One Page Checkout Invoice

Generated: 2026-06-12T13:28:38

Problem fixed:
- The previous invoice print still rendered 4 pages because the full professional invoice layout was being printed.
- v126 overrides showInvoice after all older scripts with a separate compact A4 invoice template.

What changed:
- Invoice print window is now a hard compact template, not only compressed CSS.
- QR reduced to 32mm.
- Header, totals, guest/stay details, charges/payment are arranged in tight A4 blocks.
- Designed for one A4 page for normal invoices; two pages only if data/notes are unusually long.
- The old huge invoice layout is no longer used by the print window.

Retained:
- Digital invoice QR behavior.
- v124 clean payment methods.
- v122 Tourism/Shomoos workflow.
- v123 ID type fix.
- Country list verified clean.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- showInvoice override is injected after all existing scripts.
- A4 @page print CSS is present.