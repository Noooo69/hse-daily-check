Hotel360 v143 — Troubled Rooms Center

Generated: 2026-06-19T19:18:19

Built on:
- v142 Issue Before/After Photos
- v141 Smart Room Blocking
- v140 Stable Restore
- v138 Parts Menu Toggle
- v137 Stable Permissions

Implemented stage 3:
- Troubled Rooms Center on the manager dashboard.
- Analyzes rooms by:
  * total issue count
  * open issue count
  * blocking/risky issue count
  * repeated issue types
  * stopped days
  * stopped/blocked room status
- Calculates an operational risk score per room.
- Shows suggested action:
  * root-cause inspection
  * stop sale / safety review
  * follow-up
- Quick actions:
  * open rooms page
  * create issue for the room
  * open room history/search context

Safety:
- No legacy unstable build script.
- No preview mode.
- No render/appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.