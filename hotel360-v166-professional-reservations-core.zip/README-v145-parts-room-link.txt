Hotel360 v145 — Parts Room Link

Generated: 2026-06-19T19:31:51

Built on:
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented stage 5:
- Parts requests can be linked to a room number.
- Parts requests can optionally be linked to an open issue for that room.
- Added a note field for the linked request.
- When confirming the parts cart, each purchase order stores:
  * linkedRoom
  * linkedIssueId
  * linkNote
- The purchase reason also includes room/issue/note so it is visible in existing purchase tables.
- If no room is selected, the cart still works normally.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render/appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.