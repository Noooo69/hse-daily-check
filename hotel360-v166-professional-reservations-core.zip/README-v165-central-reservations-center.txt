Hotel360 v165 — Central Reservations Center

Baseline:
- Built directly on v164 Owner Center.
- Existing check-in, issues, purchases, Owner Center, Supabase connection, and existing role behavior retained.

New roles:
- مدير حجوزات
- موظف حجوزات

New section:
- مركز الحجوزات — جميع الفنادق

Core capabilities:
- Central dashboard across all active hotels.
- Portfolio availability search by arrival/departure dates and room quantity.
- New reservation and edit workflow.
- Unified confirmation number.
- Guest contact details, nationality, preferred language, VIP flag.
- Company, travel agent, group/reference code, and booking source.
- Arrival/departure dates, room count, room type, adults and children.
- Rate plan, nightly rate, deposit, guarantee, payment method and balance.
- Reservation statuses: confirmed, tentative, waitlist, ready for arrival, arrived, departed, cancelled, no-show.
- Waitlist confirmation when inventory becomes available.
- Daily arrivals/departures list.
- Group/company/agency reservations plus reference view of existing Hotel360 campaigns.
- Aggregated guest profiles from reservation history.
- Booking source/channel analytics.
- 14-day occupancy forecast based on reservations stored in this center.
- Search and filters across all hotels.
- CSV export and print.
- Internal notes, special requests, cancellation reason, and reservation audit history.

Important scope note:
- Source labels such as Booking.com, Agoda and Expedia are reservation-source fields only in v165. This version does not connect to external OTA/channel-manager APIs and does not claim live external inventory synchronization.
- Availability is calculated from Hotel360 room inventory, rooms removed from sale, and reservations saved in this reservations center.

Start:
- Extract the ZIP.
- Run START_HOTEL360.bat, or run python -m http.server 8080 in the project folder.
