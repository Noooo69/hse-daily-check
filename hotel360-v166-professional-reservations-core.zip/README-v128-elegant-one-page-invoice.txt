Hotel360 v128 — Elegant One Page Invoice

Generated: 2026-06-12T13:50:07

Goal:
- Make invoice clearer, elegant, and one page.
- Keep the page professional, not empty or oversized.

Changes:
- New elegant A4 invoice layout.
- Compact header: title, invoice/contract, rooms, QR.
- One QR only.
- No lower barcode.
- No large green empty block.
- Clear summary cards.
- Guest, stay, payment, charges in balanced two-column cards.
- Compact signature row.
- Print button says: طباعة / PDF — صفحة واحدة.

Retained:
- Digital invoice QR.
- v124 payment method cleanup.
- v122 Tourism/Shomoos workflow.
- Country list verified clean.

QA:
- JavaScript checked with node --check for all inline scripts.
- invoicePreview and showInvoice are overridden by v128.
- v128 final script does not use old barcode renderer.