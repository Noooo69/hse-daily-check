-- Hotel360 v166 — Professional Reservations Core
-- Run in Supabase Dashboard > SQL Editor after SUPABASE_SETUP_v162.sql.
-- This migration is additive. It does not delete v165/localStorage data.

begin;
create extension if not exists pgcrypto;

-- Maps Hotel360 local IDs (h1, h2...) to the real Supabase hotels UUIDs.
create table if not exists public.h360_hotel_links_v166 (
  local_hotel_id text primary key,
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  created_at timestamptz not null default now()
);

insert into public.h360_hotel_links_v166(local_hotel_id,hotel_id)
values ('h1','11111111-1111-1111-1111-111111111111')
on conflict (local_hotel_id) do nothing;

create table if not exists public.h360_room_types_v166 (
  id text primary key,
  local_hotel_id text not null,
  code text not null,
  name text not null,
  max_adults int not null default 2 check(max_adults >= 1),
  max_children int not null default 0 check(max_children >= 0),
  manual_physical_count int not null default 0 check(manual_physical_count >= 0),
  overbook_limit int not null default 0 check(overbook_limit >= 0),
  stop_sell boolean not null default false,
  active boolean not null default true,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(local_hotel_id,code)
);

create table if not exists public.h360_room_type_map_v166 (
  local_hotel_id text not null,
  room_no text not null,
  room_type_id text references public.h360_room_types_v166(id) on delete set null,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key(local_hotel_id,room_no)
);

create table if not exists public.h360_inventory_daily_v166 (
  local_hotel_id text not null,
  room_type_id text not null references public.h360_room_types_v166(id) on delete cascade,
  stay_date date not null,
  physical_count int not null default 0,
  out_of_order_count int not null default 0,
  reserved_count int not null default 0,
  allotment_held_count int not null default 0,
  temporary_hold_count int not null default 0,
  overbook_limit int not null default 0,
  stop_sell boolean not null default false,
  version bigint not null default 0,
  updated_at timestamptz not null default now(),
  primary key(local_hotel_id,room_type_id,stay_date)
);

create table if not exists public.h360_rate_plans_v166 (
  id text primary key,
  local_hotel_id text not null,
  code text not null,
  name text not null,
  base_rate numeric(12,2) not null default 0 check(base_rate >= 0),
  refundable boolean not null default true,
  cancel_policy text not null default '',
  active boolean not null default true,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  unique(local_hotel_id,code)
);

create table if not exists public.h360_rate_rules_v166 (
  id text primary key,
  rate_plan_id text not null references public.h360_rate_plans_v166(id) on delete cascade,
  room_type_id text not null references public.h360_room_types_v166(id) on delete cascade,
  date_from date not null,
  date_to date not null,
  amount numeric(12,2) not null check(amount >= 0),
  min_stay int not null default 1 check(min_stay >= 1),
  max_stay int,
  cta boolean not null default false,
  ctd boolean not null default false,
  stop_sell boolean not null default false,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  check(date_to >= date_from)
);

create table if not exists public.h360_guest_profiles_v166 (
  id text primary key,
  full_name text not null,
  phone text,
  normalized_phone text,
  email text,
  normalized_email text,
  nationality text,
  preferred_language text,
  vip boolean not null default false,
  notes text not null default '',
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists h360_guest_phone_v166_idx on public.h360_guest_profiles_v166(normalized_phone) where normalized_phone is not null and normalized_phone<>'';
create index if not exists h360_guest_email_v166_idx on public.h360_guest_profiles_v166(normalized_email) where normalized_email is not null and normalized_email<>'';

create table if not exists public.h360_companies_v166 (
  id text primary key,
  name text not null,
  company_type text,
  credit_limit numeric(12,2) not null default 0,
  payment_terms_days int not null default 0,
  active boolean not null default true,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.h360_groups_v166 (
  id text primary key,
  local_hotel_id text not null,
  code text not null,
  name text not null,
  date_from date not null,
  date_to date not null,
  release_date date,
  status text not null default 'active',
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  unique(local_hotel_id,code)
);

create table if not exists public.h360_allotments_v166 (
  id text primary key,
  group_id text not null references public.h360_groups_v166(id) on delete cascade,
  local_hotel_id text not null,
  room_type_id text not null references public.h360_room_types_v166(id) on delete cascade,
  date_from date not null,
  date_to date not null,
  qty int not null check(qty >= 0),
  picked_up int not null default 0 check(picked_up >= 0),
  release_date date,
  active boolean not null default true,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.h360_reservations_v166 (
  id text primary key,
  confirmation_no text not null unique,
  local_hotel_id text not null,
  guest_profile_id text references public.h360_guest_profiles_v166(id) on delete set null,
  company_id text references public.h360_companies_v166(id) on delete set null,
  group_id text references public.h360_groups_v166(id) on delete set null,
  arrival_date date not null,
  departure_date date not null,
  status text not null check(status in ('inquiry','tentative','waitlist','confirmed','due_in','checked_in','checked_out','cancelled','no_show','expired','lost')),
  source text not null default 'أخرى',
  external_reservation_id text,
  quoted_total numeric(12,2) not null default 0,
  final_total numeric(12,2) not null default 0,
  special_requests text not null default '',
  internal_notes text not null default '',
  payload jsonb not null default '{}'::jsonb,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check(departure_date > arrival_date)
);
create index if not exists h360_res_dates_v166_idx on public.h360_reservations_v166(local_hotel_id,arrival_date,departure_date);
create index if not exists h360_res_status_v166_idx on public.h360_reservations_v166(local_hotel_id,status);

create table if not exists public.h360_reservation_units_v166 (
  id text primary key,
  reservation_id text not null references public.h360_reservations_v166(id) on delete cascade,
  room_type_id text not null references public.h360_room_types_v166(id),
  rate_plan_id text references public.h360_rate_plans_v166(id),
  adults int not null default 1,
  children int not null default 0,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.h360_daily_rates_v166 (
  reservation_unit_id text not null references public.h360_reservation_units_v166(id) on delete cascade,
  stay_date date not null,
  amount numeric(12,2) not null default 0,
  discount numeric(12,2) not null default 0,
  tax numeric(12,2) not null default 0,
  source_rule_id text,
  primary key(reservation_unit_id,stay_date)
);

create table if not exists public.h360_booking_room_assignments_v166 (
  unit_id text primary key references public.h360_reservation_units_v166(id) on delete cascade,
  reservation_id text not null references public.h360_reservations_v166(id) on delete cascade,
  local_hotel_id text not null,
  room_no text not null,
  assigned_from date not null,
  assigned_to date not null,
  payload jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.h360_payments_v166 (
  id text primary key,
  reservation_id text not null references public.h360_reservations_v166(id) on delete cascade,
  payment_type text not null,
  amount numeric(12,2) not null,
  method text,
  status text not null,
  reference text,
  token_reference text,
  paid_at timestamptz,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.h360_guarantees_v166 (
  id text primary key,
  reservation_id text not null references public.h360_reservations_v166(id) on delete cascade,
  guarantee_type text not null,
  required_amount numeric(12,2) not null default 0,
  due_at timestamptz,
  status text not null default 'pending',
  token_reference text,
  payload jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table if not exists public.h360_audit_v166 (
  id text primary key,
  local_hotel_id text,
  entity_type text not null,
  entity_id text not null,
  action text not null,
  actor_user_id uuid references auth.users(id),
  actor_name text,
  actor_role text,
  old_values jsonb,
  new_values jsonb,
  created_at timestamptz not null default now()
);

-- Authorization helpers.
create or replace function public.h360_v166_is_approved()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.status='approved');
$$;

create or replace function public.h360_v166_is_res_staff()
returns boolean language sql stable security definer set search_path=public as $$
  select public.h360_is_main_admin() or exists(
    select 1 from public.memberships m
    where m.user_id=auth.uid() and m.is_active=true
      and m.role_key in ('reservations_manager','reservations_agent','admin_supervisor','admin_assistant','hotel_admin','hotel_manager','reception')
  );
$$;

create or replace function public.h360_v166_can_hotel(p_local_hotel_id text)
returns boolean language sql stable security definer set search_path=public as $$
  select public.h360_is_main_admin() or exists(
    select 1
    from public.h360_hotel_links_v166 l
    join public.memberships m on m.hotel_id=l.hotel_id
    where l.local_hotel_id=p_local_hotel_id
      and m.user_id=auth.uid() and m.is_active=true
      and m.role_key in ('reservations_manager','reservations_agent','admin_supervisor','admin_assistant','hotel_admin','hotel_manager','reception')
  );
$$;

-- RLS.
alter table public.h360_hotel_links_v166 enable row level security;
alter table public.h360_room_types_v166 enable row level security;
alter table public.h360_room_type_map_v166 enable row level security;
alter table public.h360_inventory_daily_v166 enable row level security;
alter table public.h360_rate_plans_v166 enable row level security;
alter table public.h360_rate_rules_v166 enable row level security;
alter table public.h360_guest_profiles_v166 enable row level security;
alter table public.h360_companies_v166 enable row level security;
alter table public.h360_groups_v166 enable row level security;
alter table public.h360_allotments_v166 enable row level security;
alter table public.h360_reservations_v166 enable row level security;
alter table public.h360_reservation_units_v166 enable row level security;
alter table public.h360_daily_rates_v166 enable row level security;
alter table public.h360_booking_room_assignments_v166 enable row level security;
alter table public.h360_payments_v166 enable row level security;
alter table public.h360_guarantees_v166 enable row level security;
alter table public.h360_audit_v166 enable row level security;

-- Generic portfolio staff tables.
drop policy if exists h360_v166_links_admin on public.h360_hotel_links_v166;
create policy h360_v166_links_admin on public.h360_hotel_links_v166 for all to authenticated
using (public.h360_is_main_admin()) with check (public.h360_is_main_admin());

drop policy if exists h360_v166_guests_staff on public.h360_guest_profiles_v166;
create policy h360_v166_guests_staff on public.h360_guest_profiles_v166 for all to authenticated
using (public.h360_v166_is_res_staff()) with check (public.h360_v166_is_res_staff());

drop policy if exists h360_v166_companies_staff on public.h360_companies_v166;
create policy h360_v166_companies_staff on public.h360_companies_v166 for all to authenticated
using (public.h360_v166_is_res_staff()) with check (public.h360_v166_is_res_staff());

-- Hotel-scoped tables.
drop policy if exists h360_v166_rt_staff on public.h360_room_types_v166;
create policy h360_v166_rt_staff on public.h360_room_types_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

drop policy if exists h360_v166_map_staff on public.h360_room_type_map_v166;
create policy h360_v166_map_staff on public.h360_room_type_map_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

drop policy if exists h360_v166_inv_staff on public.h360_inventory_daily_v166;
create policy h360_v166_inv_staff on public.h360_inventory_daily_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

drop policy if exists h360_v166_rates_staff on public.h360_rate_plans_v166;
create policy h360_v166_rates_staff on public.h360_rate_plans_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

drop policy if exists h360_v166_groups_staff on public.h360_groups_v166;
create policy h360_v166_groups_staff on public.h360_groups_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

drop policy if exists h360_v166_allot_staff on public.h360_allotments_v166;
create policy h360_v166_allot_staff on public.h360_allotments_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

drop policy if exists h360_v166_res_staff on public.h360_reservations_v166;
create policy h360_v166_res_staff on public.h360_reservations_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

drop policy if exists h360_v166_assign_staff on public.h360_booking_room_assignments_v166;
create policy h360_v166_assign_staff on public.h360_booking_room_assignments_v166 for all to authenticated
using (public.h360_v166_can_hotel(local_hotel_id)) with check (public.h360_v166_can_hotel(local_hotel_id));

-- Child-table access follows the parent reservation / plan.
drop policy if exists h360_v166_rules_staff on public.h360_rate_rules_v166;
create policy h360_v166_rules_staff on public.h360_rate_rules_v166 for all to authenticated
using (exists(select 1 from public.h360_rate_plans_v166 p where p.id=rate_plan_id and public.h360_v166_can_hotel(p.local_hotel_id)))
with check (exists(select 1 from public.h360_rate_plans_v166 p where p.id=rate_plan_id and public.h360_v166_can_hotel(p.local_hotel_id)));

drop policy if exists h360_v166_units_staff on public.h360_reservation_units_v166;
create policy h360_v166_units_staff on public.h360_reservation_units_v166 for all to authenticated
using (exists(select 1 from public.h360_reservations_v166 r where r.id=reservation_id and public.h360_v166_can_hotel(r.local_hotel_id)))
with check (exists(select 1 from public.h360_reservations_v166 r where r.id=reservation_id and public.h360_v166_can_hotel(r.local_hotel_id)));

drop policy if exists h360_v166_daily_staff on public.h360_daily_rates_v166;
create policy h360_v166_daily_staff on public.h360_daily_rates_v166 for all to authenticated
using (exists(select 1 from public.h360_reservation_units_v166 u join public.h360_reservations_v166 r on r.id=u.reservation_id where u.id=reservation_unit_id and public.h360_v166_can_hotel(r.local_hotel_id)))
with check (exists(select 1 from public.h360_reservation_units_v166 u join public.h360_reservations_v166 r on r.id=u.reservation_id where u.id=reservation_unit_id and public.h360_v166_can_hotel(r.local_hotel_id)));

drop policy if exists h360_v166_payments_staff on public.h360_payments_v166;
create policy h360_v166_payments_staff on public.h360_payments_v166 for all to authenticated
using (exists(select 1 from public.h360_reservations_v166 r where r.id=reservation_id and public.h360_v166_can_hotel(r.local_hotel_id)))
with check (exists(select 1 from public.h360_reservations_v166 r where r.id=reservation_id and public.h360_v166_can_hotel(r.local_hotel_id)));

drop policy if exists h360_v166_guarantees_staff on public.h360_guarantees_v166;
create policy h360_v166_guarantees_staff on public.h360_guarantees_v166 for all to authenticated
using (exists(select 1 from public.h360_reservations_v166 r where r.id=reservation_id and public.h360_v166_can_hotel(r.local_hotel_id)))
with check (exists(select 1 from public.h360_reservations_v166 r where r.id=reservation_id and public.h360_v166_can_hotel(r.local_hotel_id)));

drop policy if exists h360_v166_audit_staff on public.h360_audit_v166;
create policy h360_v166_audit_staff on public.h360_audit_v166 for select to authenticated
using (public.h360_is_main_admin() or (local_hotel_id is not null and public.h360_v166_can_hotel(local_hotel_id)));
create policy h360_v166_audit_insert on public.h360_audit_v166 for insert to authenticated
with check (public.h360_v166_is_res_staff());

-- Atomic inventory helpers for the production path. The web UI can adopt these RPCs once
-- inventory_daily is populated from physical room inventory.
create or replace function public.h360_v166_reserve_inventory(
  p_local_hotel_id text,
  p_room_type_id text,
  p_arrival date,
  p_departure date,
  p_qty int,
  p_allow_overbook boolean default false
) returns void
language plpgsql security definer set search_path=public as $$
declare rec record; available_now int;
begin
  if not public.h360_v166_can_hotel(p_local_hotel_id) then raise exception 'not_authorized'; end if;
  if p_qty < 1 or p_departure <= p_arrival then raise exception 'invalid_request'; end if;
  for rec in
    select * from public.h360_inventory_daily_v166
    where local_hotel_id=p_local_hotel_id and room_type_id=p_room_type_id
      and stay_date>=p_arrival and stay_date<p_departure
    order by stay_date
    for update
  loop
    available_now := greatest(0, rec.physical_count-rec.out_of_order_count + case when p_allow_overbook then rec.overbook_limit else 0 end - rec.reserved_count-rec.allotment_held_count-rec.temporary_hold_count);
    if rec.stop_sell then raise exception 'stop_sell on %',rec.stay_date; end if;
    if available_now < p_qty then raise exception 'insufficient_inventory on %',rec.stay_date; end if;
  end loop;
  if (select count(*) from public.h360_inventory_daily_v166 where local_hotel_id=p_local_hotel_id and room_type_id=p_room_type_id and stay_date>=p_arrival and stay_date<p_departure) <> (p_departure-p_arrival) then
    raise exception 'inventory_calendar_incomplete';
  end if;
  update public.h360_inventory_daily_v166
  set reserved_count=reserved_count+p_qty,version=version+1,updated_at=now()
  where local_hotel_id=p_local_hotel_id and room_type_id=p_room_type_id and stay_date>=p_arrival and stay_date<p_departure;
end;$$;

create or replace function public.h360_v166_release_inventory(
  p_local_hotel_id text,
  p_room_type_id text,
  p_arrival date,
  p_departure date,
  p_qty int
) returns void
language plpgsql security definer set search_path=public as $$
begin
  if not public.h360_v166_can_hotel(p_local_hotel_id) then raise exception 'not_authorized'; end if;
  update public.h360_inventory_daily_v166
  set reserved_count=greatest(0,reserved_count-p_qty),version=version+1,updated_at=now()
  where local_hotel_id=p_local_hotel_id and room_type_id=p_room_type_id and stay_date>=p_arrival and stay_date<p_departure;
end;$$;

commit;
