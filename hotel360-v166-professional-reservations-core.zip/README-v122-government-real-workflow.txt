Hotel360 v122 — Reception Government Real Workflow
Generated: 2026-06-12T02:19:56

Base:
- Built over v121/v120/v119/v118/v115/v114/v111/v107/v104.

Changes:
- Tourism and Shomoos remain in the upper white reception toolbar only.
- Added functional workflow, not just UI:
  1) Reads active check-ins.
  2) Validates required guest fields.
  3) Shows ready / missing / sent status.
  4) Exports selected guests to CSV.
  5) Exports selected guests to JSON.
  6) Copies selected payloads.
  7) Marks selected guests as sent inside Hotel360 local operational log.
  8) Allows resetting selected guests to unsent.
  9) Stores submission history in state.govSubmissions.

Important:
- Official direct submission to Ministry of Tourism/Shomoos still requires official API credentials and integration approval.
- This version implements a real internal preparation/export/status workflow and prevents blind buttons with no action.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- index.html exists in root.
- images/tourism-logo.webp exists.
- images/shomoos-logo.jpg exists.
- Country list verified clean.