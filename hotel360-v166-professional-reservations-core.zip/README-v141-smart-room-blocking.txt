Hotel360 v141 — Smart Room Blocking

Generated: 2026-06-19T19:04:46

Built on stable:
- v140 Stable Restore No legacy unstable build
- v138 parts menu toggle fix
- v137 stable permissions no recursion
- v130 parts image storage
- v129 one-page invoice

Implemented only stage 1:
- Smart room blocking / منع التسكين الذكي.
- Risk/high/blocking issues stop the room.
- check-in blocker checks smart blocks and active blocking issues.
- Rooms page shows blocked rooms and approval button.
- Issues page has "إغلاق واعتماد" for blocking issues.
- Room returns to sale only when active blocking issues are closed.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render/appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.