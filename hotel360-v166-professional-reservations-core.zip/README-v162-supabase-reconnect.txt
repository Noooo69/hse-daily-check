Hotel360 v162 — Supabase Reconnect
Base: v161 only.

Changes:
- Reconnected frontend to the newly created Supabase project.
- Replaced only the public Project URL and Publishable key.
- Added real Supabase Auth signup when the backend schema is installed.
- Kept local signup queue only as a local-test fallback.
- Kept v161 password-reset fail-closed behavior.
- Did not change check-in/housing, incident routing, or existing role permissions.

One-time backend setup:
Run SUPABASE_SETUP_v162.sql in Supabase SQL Editor.
Then add http://localhost:8080/** to Authentication redirect URLs for local password-reset testing.
Later add the production Cloudflare URL too.

Never place database passwords, Secret keys, or service-role keys in index.html.
