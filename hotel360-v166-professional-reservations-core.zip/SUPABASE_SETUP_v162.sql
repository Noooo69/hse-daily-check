-- Hotel360 v162 — Supabase bootstrap schema
-- Run once in Supabase Dashboard > SQL Editor > New query > Run.

begin;
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null unique,
  full_name text not null default '',
  status text not null default 'pending' check (status in ('pending','approved','disabled','rejected')),
  is_main_admin boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.hotels (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  city text not null default '',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

insert into public.hotels (id,name,city,is_active)
values ('11111111-1111-1111-1111-111111111111','ديار واحة النزيل','مكة',true)
on conflict (id) do update set name=excluded.name,city=excluded.city,is_active=true,updated_at=now();

create table if not exists public.memberships (
  user_id uuid not null references auth.users(id) on delete cascade,
  hotel_id uuid not null references public.hotels(id) on delete cascade,
  role_key text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (user_id,hotel_id,role_key)
);

create or replace function public.h360_handle_new_user()
returns trigger language plpgsql security definer set search_path=public as $$
declare is_owner boolean := lower(coalesce(new.email,''))=lower('cccoccc15@hotmail.com');
begin
  insert into public.profiles(id,email,full_name,status,is_main_admin,created_at,updated_at)
  values(new.id,coalesce(new.email,''),coalesce(new.raw_user_meta_data->>'full_name',''),case when is_owner then 'approved' else 'pending' end,is_owner,now(),now())
  on conflict (id) do update set
    email=excluded.email,
    full_name=case when excluded.full_name<>'' then excluded.full_name else public.profiles.full_name end,
    is_main_admin=(public.profiles.is_main_admin or excluded.is_main_admin),
    status=case when excluded.is_main_admin then 'approved' else public.profiles.status end,
    updated_at=now();
  return new;
end;$$;

drop trigger if exists h360_on_auth_user_created on auth.users;
create trigger h360_on_auth_user_created after insert or update of email,raw_user_meta_data on auth.users
for each row execute procedure public.h360_handle_new_user();

create or replace function public.h360_is_main_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.profiles p where p.id=auth.uid() and p.is_main_admin=true and p.status='approved');
$$;

alter table public.profiles enable row level security;
alter table public.hotels enable row level security;
alter table public.memberships enable row level security;

drop policy if exists profiles_read_self_or_admin on public.profiles;
create policy profiles_read_self_or_admin on public.profiles for select to authenticated
using (id=auth.uid() or public.h360_is_main_admin());

drop policy if exists profiles_admin_update on public.profiles;
create policy profiles_admin_update on public.profiles for update to authenticated
using (public.h360_is_main_admin()) with check (public.h360_is_main_admin());

drop policy if exists hotels_authenticated_read on public.hotels;
create policy hotels_authenticated_read on public.hotels for select to authenticated using (true);

drop policy if exists hotels_admin_all on public.hotels;
create policy hotels_admin_all on public.hotels for all to authenticated
using (public.h360_is_main_admin()) with check (public.h360_is_main_admin());

drop policy if exists memberships_read_self_or_admin on public.memberships;
create policy memberships_read_self_or_admin on public.memberships for select to authenticated
using (user_id=auth.uid() or public.h360_is_main_admin());

drop policy if exists memberships_admin_all on public.memberships;
create policy memberships_admin_all on public.memberships for all to authenticated
using (public.h360_is_main_admin()) with check (public.h360_is_main_admin());

insert into public.profiles(id,email,full_name,status,is_main_admin,created_at,updated_at)
select u.id,coalesce(u.email,''),coalesce(u.raw_user_meta_data->>'full_name',''),
       case when lower(coalesce(u.email,''))=lower('cccoccc15@hotmail.com') then 'approved' else 'pending' end,
       lower(coalesce(u.email,''))=lower('cccoccc15@hotmail.com'),now(),now()
from auth.users u
on conflict (id) do update set
  email=excluded.email,
  full_name=case when excluded.full_name<>'' then excluded.full_name else public.profiles.full_name end,
  is_main_admin=(public.profiles.is_main_admin or excluded.is_main_admin),
  status=case when excluded.is_main_admin then 'approved' else public.profiles.status end,
  updated_at=now();

commit;
