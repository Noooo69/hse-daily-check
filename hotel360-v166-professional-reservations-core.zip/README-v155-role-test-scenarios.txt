Hotel360 v155 — Role Test Scenarios

Generated: 2026-06-20T00:51:28

Built on:
- v154 Dashboard Sections Bottom
- v153 Sidebar Professional Cleanup
- v152 All Interfaces Cleanup
- v151 Dashboard Cleanup
- v150 VIP Sensitive Center
- v149 Room Loss Indicator
- v148 Department Performance
- v147 Government Visit Readiness
- v146 Technician Custody
- v145 Parts Room Link
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented:
- Admin-only role test mode.
- Added to Admin page:
  * Test as main admin
  * Hotel manager
  * Reception
  * Maintenance manager
  * Electrician
  * Plumber
  * Warehouse manager
  * Purchasing manager
  * Quality
  * HSE
  * Housekeeping
  * Viewer
- Switching role changes state.user to a temporary local test user.
- Sticky yellow banner appears in test mode.
- Banner includes:
  * Current test role
  * Return to admin
  * Quick navigation buttons
- Original admin user is stored and restored when clicking "رجوع للأدمن".
- Added Hotel360 scenario checklist:
  * reset demo
  * normal check-in
  * VIP check-in
  * risky issue / room blocking
  * before/after photos
  * parts request linked to room
  * technician custody
  * shift handover
  * government readiness
  * role testing
  * dashboard review
- Checklist can be marked done, reset, or copied.

No business logic changes:
- Does not modify Reception, Issues, Parts, Purchases, Rooms behavior.
- Does not modify permissions logic itself; it only changes the current user temporarily for testing.
- Does not override render or appView.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render wrapper.
- No appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.