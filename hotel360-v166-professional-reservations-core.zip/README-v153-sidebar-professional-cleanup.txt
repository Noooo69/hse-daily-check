Hotel360 v153 — Sidebar Professional Cleanup

Generated: 2026-06-20T00:35:49

Built on:
- v152 All Interfaces Cleanup
- v151 Dashboard Cleanup
- v150 VIP Sensitive Center
- v149 Room Loss Indicator
- v148 Department Performance
- v147 Government Visit Readiness
- v146 Technician Custody
- v145 Parts Room Link
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented:
- Professional compact sidebar only.
- Desktop sidebar width reduced to 244px.
- Mobile sidebar reduced to 300px / 286px on smaller screens.
- Smaller Hotel360 logo area.
- Smaller nav font and tighter spacing.
- Better active item styling with gold indicator.
- Section labels translated:
  * CORE -> التشغيل
  * SYSTEM -> النظام
- Icons wrapped into consistent small icon boxes.
- Parts submenu made smaller and cleaner.
- Scrollbar made thinner and cleaner.

No business logic changes:
- Does not modify Reception, Issues, Parts, Purchases, Rooms behavior.
- Does not modify permissions, data, calculations, blocking, photos, custody, or handover.
- Does not override render or appView.
- Uses safe DOM enhancement after render.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render wrapper.
- No appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.