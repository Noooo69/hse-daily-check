Hotel360 v150 — VIP Sensitive Center

Generated: 2026-06-19T22:01:01

Built on:
- v149 Room Loss Indicator
- v148 Department Performance
- v147 Government Visit Readiness
- v146 Technician Custody
- v145 Parts Room Link
- v144 Reception Shift Handover
- v143 Troubled Rooms Center
- v142 Issue Before/After Photos
- v141 Smart Room Blocking

Implemented stage 10:
- VIP and sensitive notes center on manager dashboard.
- Shows active VIP guests based on vipLevel / vipNote from check-in.
- Tracks:
  * active VIP guests
  * open sensitive notes
  * urgent notes
  * VIP due out today
- Allows adding a sensitive note:
  * linked to active guest or general note
  * priority: متابعة / مهم / عاجل
  * note body
- Notes can be marked done or deleted.
- Quick action opens guest context in Reception smart search.

Safety:
- No legacy unstable build script.
- No preview mode.
- No render/appView wrapper.
- No function recursive wrapper hazard pattern.

QA:
- JavaScript syntax checked with node --check for all inline scripts.
- Recursive wrapper hazard / hoisting hazard scan: 0 hazards.
- Country list verified clean.