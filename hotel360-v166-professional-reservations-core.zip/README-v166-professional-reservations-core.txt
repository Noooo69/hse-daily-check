Hotel360 v166 — Professional Reservations Core
================================================

هذه النسخة تطبق فعليًا داخل قسم الحجوزات نتائج الدراسة السابقة بدل إعادة البحث.

أهم ما تم تطبيقه داخل الموقع:
- فصل Reservation عن Room Assignment وعن Check-in/Check-out.
- نموذج Room Type مستقل لكل فندق مع ربط أرقام الغرف الفعلية به.
- Availability حسب الفندق + نوع الغرفة + ليلة الإقامة.
- خصم الغرف خارج الخدمة/الصيانة من المخزون.
- Overbooking Limit وStop Sell لكل نوع غرفة.
- Look-to-Book: بحث توفر وأسعار لجميع الفنادق ثم إضافة العرض إلى سلة الحجز.
- Rate Plans مستقلة مع Daily Rates وMinLOS / MaxLOS / CTA / CTD / Stop Sell.
- حفظ سعر الحجز Snapshot داخل كل ليلة للحجز، فلا يتغير الحجز القديم بصمت عند تعديل الأسعار.
- Reservation Units: كل غرفة في الحجز تصبح وحدة مستقلة يمكن تخصيص غرفة فعلية لها لاحقًا.
- Guest Profiles دائمة؛ المطابقة التلقائية تعتمد البريد أو الجوال، وليس الاسم فقط.
- دورة حالات مضبوطة State Machine: Inquiry / Tentative / Waitlist / Confirmed / Due In / No-show / Cancelled ...
- قائمة انتظار بأولوية وسبب مع فحص التوفر عند التحويل إلى مؤكد.
- شركات ووكالات + Groups/Blocks + Allotments + Release Date + Pickup.
- تخصيص الغرف منفصل عن Check-in، مع منع تخصيص غرفة مشغولة أو خارج الخدمة.
- تسليم الحجوزات إلى قائمة تشغيل الاستقبال بدون تنفيذ Check-in من قسم الحجوزات.
- Payment Ledger وGuarantees بدون تخزين PAN/CVV.
- سجل تدقيق Append-only داخل v166 لكل إنشاء/حالة/تخصيص/دفعة/مزامنة.
- تقارير Occupancy / ADR / RevPAR + توقع 14 يومًا + أداء المصادر.
- تصدير CSV وJSON.
- ترحيل آمن تلقائي من سجلات v165 إلى النموذج الجديد مع الاحتفاظ بنسخة Backup داخل state.v166.legacyBackup.
- مزامنة Supabase اختيارية بعد تشغيل ملف SQL المرفق.

ملفات v166 الجديدة:
- v166-reservations.css
- v166-reservations.js
- SUPABASE_V166_RESERVATIONS_CORE.sql
- README-v166-professional-reservations-core.txt
- QA_REPORT-v166-professional-reservations-core.txt

مهم بخصوص Supabase:
الموقع يعمل Local-first مباشرة حتى قبل تشغيل SQL. لكي تصبح جداول v166 موجودة في Supabase استخدم:
SUPABASE_V166_RESERVATIONS_CORE.sql
بعد تشغيله يمكن الضغط من تبويب "المزامنة" داخل مركز الحجوزات على "اختبار جداول v166" ثم "مزامنة الآن".

مهم بخصوص Double Booking:
منع التعارض داخل نفس بيانات المتصفح مطبق الآن. منع بيع آخر غرفة مرتين بين جهازين في نفس اللحظة يحتاج أن يكون الحفظ النهائي عبر transaction/RPC في Supabase. أضيفت في SQL دوال h360_v166_reserve_inventory و h360_v166_release_inventory لتأسيس هذا المسار الإنتاجي، لكن الواجهة الحالية ما زالت Local-first + Sync وليست Backend-authoritative بالكامل.

مهم بخصوص Booking.com / Agoda / Expedia:
تبقى أسماء مصادر حجز فقط. لا توجد مزامنة OTA حقيقية بدون Channel Manager/API credentials. لم يتم الادعاء بعكس ذلك.

التشغيل المحلي:
استخدم START_HOTEL360.bat أو شغّل خادم HTTP محلي. لا تفتح index.html بوضع file:// إذا أردت Supabase/Auth/Network بشكل صحيح.
