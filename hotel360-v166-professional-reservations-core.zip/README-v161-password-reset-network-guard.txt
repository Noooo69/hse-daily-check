Hotel360 v161 — Password Reset Network Guard

Built directly on v160 Role Home Engine.

Changes:
- Real Supabase password-reset flow remains the only password recovery path.
- Failed network/service calls no longer show a misleading SMTP/rate-limit-only alert.
- The reset screen now reports connection failure clearly and preserves the entered email for retry.
- Added a 12-second request timeout so the recovery call does not wait indefinitely.
- Localhost failures fail closed: no local password bypass is created.
- Successful Supabase responses still move to the email-sent view.

Not changed:
- Role permissions.
- Housing/check-in logic.
- Incident/report logic.
- v160 role-home interfaces.
