Hotel360 v159 — Reception Permission Hardening

Built directly on v158 only.

Changes:
- Reception accounts are restricted to their approved reception pages: Reception, Rooms, New Issue, Issues, Regulations, and Room History.
- Reception cannot open Manager Dashboard, Purchases, Parts Catalog, Smart Operations, or Admin Panel.
- Direct navigation to unauthorized pages is blocked, not merely hidden from the sidebar.
- Admin identity now requires an effective approved admin role; a stale role/email mismatch cannot grant admin access.
- Unknown local accounts can no longer auto-enter as a demo reception user. They must be approved first.
- Existing admin and other role page maps remain aligned with the stable permission map.
- No changes to room-assignment logic or issue workflow logic.
