Hotel360 v157 — Local Signup Queue Fix
Base: v156 Baseline Safety Cleanup only.

Changes:
- Fixed local Create Account flow so a request is saved to state.pendingSignup/localStorage.
- Pending local account now appears in Admin > New Account Requests on the same browser/origin.
- Pending local account cannot use the local login flow before approval.
- After local admin approval, the approved user logs in with the assigned role and hotel in local demo mode.
- Local queue items are never sent to Supabase approval code accidentally.
- Updated local-mode wording to clarify same-browser testing vs real multi-device backend behavior.

Not changed:
- Housing/room assignment logic.
- Incident/report logic.
- Role permission rules.
- v155 Role Test Scenarios logic.

Security note:
- Local demo mode is for testing only. It does not provide production authentication or password verification across devices.
