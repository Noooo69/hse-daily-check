Hotel360 v163 — Mobile LAN Launcher

Built directly on v162 only.

What changed
- Added START_HOTEL360.bat for one-click Windows startup.
- Server binds to 0.0.0.0 so other devices on the same Wi-Fi can reach Hotel360.
- Launcher detects the PC LAN IPv4 address and prints the phone URL.
- Opens http://localhost:8080 automatically on the PC.
- Updated page title/version marker to v163.

What did NOT change
- Room/check-in logic.
- Issues/reporting logic.
- Role/permission rules.
- Supabase project configuration and authentication logic.
- Role Home Engine behavior.

Important
- http://localhost:8080 works only on the PC that runs the server.
- On a phone, use the printed http://<PC-IP>:8080 address and keep both devices on the same Wi-Fi.
- A phone using 5G/mobile data cannot reach this local server. Public access requires deployment to Cloudflare Pages or another public host.
