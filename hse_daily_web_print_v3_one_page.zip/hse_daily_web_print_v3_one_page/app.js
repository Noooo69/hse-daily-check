const items = [
"لوحة التحكم الرئيسية + الطابعة",
"غرفة مضخات الحريق",
"غرفة المولد الاحتياطي",
"نظام الدفع والشفط بالبدرومات",
"التخزين بالبدرومات",
"طفايات الحريق",
"كاشف الدخان + كاشف الحرارة",
"نظام الإخماد FM200",
"اللوحات الإرشادية والإضاءات التحذيرية",
"نظام الإخماد الرغوي FOAM",
"نظام الرش الآلي",
"غرفة خزان الديزل",
"المصاعد",
"عوائق أمام صناديق الإطفاء",
"إنارة الطوارئ",
"عوائق في سلم الطوارئ",
"أبواب ومخارج الطوارئ",
"التخزين في الغرف الكهربائية والميكانيكية",
"مخارج الطوارئ مفتوحة وغير مقفلة",
"طفايات الحريق ضغطها سليم ومسمار الأمان موجود",
"خراطيم الحريق وصناديق الإطفاء بحالة جيدة",
"لوحة الإنذار لا تظهر Fault / Trouble",
"مسارات الهروب خالية من العوائق",
"أبواب الحريق تغلق تلقائيًا",
"لا يوجد تخزين عشوائي في الممرات",
"لا توجد أسلاك كهربائية مكشوفة أو تمديدات عشوائية",
"المولد / مضخة الحريق جاهزة للتشغيل",
"النظافة حول غرف الكهرباء والمضخات جيدة",
"خطة الإخلاء ومسارات الهروب معلقة ومحدثة",
"خرائط الإخلاء موجودة داخل الغرف والأدوار",
"نقطة التجمع واضحة وخالية من العوائق"
];

const days = ["الأحد","الإثنين","الثلاثاء","الأربعاء","الخميس","الجمعة","السبت"];
const $ = id => document.getElementById(id);

function todayISO(){
  const d = new Date();
  const offset = d.getTimezoneOffset();
  const local = new Date(d.getTime() - offset * 60000);
  return local.toISOString().slice(0,10);
}
function getRadio(name){
  const el = document.querySelector(`input[name="${name}"]:checked`);
  return el ? el.value : "";
}
function setRadio(name,value){
  if(!value) return;
  const el = document.querySelector(`input[name="${name}"][value="${value}"]`);
  if(el) el.checked = true;
}
function renderChecklist(){
  $("checklist").innerHTML = items.map((text,index)=>{
    const n = index + 1;
    return `<article class="item">
      <h3><span class="num">${n}</span><span>${text}</span></h3>
      <div class="group-title">الحالة</div>
      <div class="options">
        <label><input type="radio" name="status_${n}" value="يعمل"><b>يعمل</b></label>
        <label><input type="radio" name="status_${n}" value="يحتاج صيانة"><b>يحتاج صيانة</b></label>
        <label><input type="radio" name="status_${n}" value="متعطل"><b>متعطل</b></label>
      </div>
      <div class="group-title">درجة الخطورة</div>
      <div class="options sev">
        <label><input type="radio" name="severity_${n}" value="منخفضة"><b>منخفضة</b></label>
        <label><input type="radio" name="severity_${n}" value="متوسطة"><b>متوسطة</b></label>
        <label><input type="radio" name="severity_${n}" value="عالية"><b>عالية</b></label>
        <label><input type="radio" name="severity_${n}" value="حرجة"><b>حرجة</b></label>
      </div>
      <div class="mini-grid">
        <label><span>الموقع</span><input id="location_${n}" type="text" placeholder="مثال: الدور الثاني"></label>
        <label><span>الملاحظة</span><textarea id="note_${n}" placeholder="اكتب الملاحظة عند الحاجة"></textarea></label>
      </div>
    </article>`;
  }).join("");
}
function updateDay(){
  if(!$("date").value) return;
  const d = new Date($("date").value + "T12:00:00");
  $("day").value = days[d.getDay()];
}
function collect(){
  const data = {
    hotel:$("hotel").value,
    date:$("date").value,
    day:$("day").value,
    inspector:$("inspector").value,
    startTime:$("startTime").value,
    endTime:$("endTime").value,
    shift:getRadio("shift"),
    supervisor:$("supervisor").value,
    rows:[]
  };
  items.forEach((item,i)=>{
    const n = i + 1;
    data.rows.push({
      n, item,
      status:getRadio(`status_${n}`),
      severity:getRadio(`severity_${n}`),
      location:$(`location_${n}`).value,
      note:$(`note_${n}`).value
    });
  });
  return data;
}
function save(){
  localStorage.setItem("hse_daily_check_print_v3", JSON.stringify(collect()));
  alert("تم الحفظ على هذا الجهاز.");
}
function load(){
  const raw = localStorage.getItem("hse_daily_check_print_v3");
  if(!raw) return;
  try{
    const data = JSON.parse(raw);
    ["hotel","date","day","inspector","startTime","endTime","supervisor"].forEach(id=>{
      if(data[id] !== undefined) $(id).value = data[id];
    });
    setRadio("shift", data.shift);
    if(Array.isArray(data.rows)){
      data.rows.forEach(row=>{
        setRadio(`status_${row.n}`, row.status);
        setRadio(`severity_${row.n}`, row.severity);
        if($(`location_${row.n}`)) $(`location_${row.n}`).value = row.location || "";
        if($(`note_${row.n}`)) $(`note_${row.n}`).value = row.note || "";
      });
    }
  }catch(e){}
}
function clearAll(){
  if(confirm("هل تريد مسح البيانات؟")){
    localStorage.removeItem("hse_daily_check_print_v3");
    location.reload();
  }
}
function summary(){
  let ok=0, maint=0, bad=0, critical=0;
  items.forEach((_,i)=>{
    const n = i + 1;
    const status = getRadio(`status_${n}`);
    const severity = getRadio(`severity_${n}`);
    if(status === "يعمل") ok++;
    if(status === "يحتاج صيانة") maint++;
    if(status === "متعطل") bad++;
    if(severity === "حرجة") critical++;
  });
  $("okCount").textContent = ok;
  $("maintCount").textContent = maint;
  $("badCount").textContent = bad;
  $("criticalCount").textContent = critical;
}
function esc(x){
  return String(x || "").replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
function preparePrint(){
  const data = collect();
  $("printInfo").innerHTML = `
    <div>اسم الفندق: ${esc(data.hotel)}</div>
    <div>التاريخ: ${esc(data.date)}</div>
    <div>اليوم: ${esc(data.day)}</div>
    <div>الشفت: ${esc(data.shift)}</div>
    <div>اسم المفتش: ${esc(data.inspector)}</div>
    <div>وقت بداية الجولة: ${esc(data.startTime)}</div>
    <div>وقت نهاية الجولة: ${esc(data.endTime)}</div>
    <div>المسؤول المناوب: ${esc(data.supervisor)}</div>`;
  $("printRows").innerHTML = data.rows.map(r=>{
    return `<tr>
      <td class="center">${r.n}</td>
      <td>${esc(r.item)}</td>
      <td>${esc(r.location)}</td>
      <td class="center">${r.status === "يعمل" ? "✓" : ""}</td>
      <td class="center">${r.status === "يحتاج صيانة" ? "✓" : ""}</td>
      <td class="center">${r.status === "متعطل" ? "✓" : ""}</td>
      <td class="center">${r.severity === "منخفضة" ? "✓" : ""}</td>
      <td class="center">${r.severity === "متوسطة" ? "✓" : ""}</td>
      <td class="center">${r.severity === "عالية" ? "✓" : ""}</td>
      <td class="center">${r.severity === "حرجة" ? "✓" : ""}</td>
      <td>${esc(r.note)}</td>
    </tr>`;
  }).join("");
}

renderChecklist();
$("date").value = todayISO();
updateDay();
load();
summary();
$("date").addEventListener("change", updateDay);
document.body.addEventListener("change", summary);
$("saveBtn").addEventListener("click", save);
$("clearBtn").addEventListener("click", clearAll);
$("printBtn").addEventListener("click", () => window.print());
$("printBtn2").addEventListener("click", () => window.print());
window.addEventListener("beforeprint", preparePrint);
